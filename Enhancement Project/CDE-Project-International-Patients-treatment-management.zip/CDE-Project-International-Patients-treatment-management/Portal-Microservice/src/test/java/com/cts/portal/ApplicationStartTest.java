package com.cts.portal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationStartTest {

	@Test
	void test() {
		PortalMicroserviceApplication.main(new String[] {});
	}
}
