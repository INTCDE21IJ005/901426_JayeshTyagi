package com.cts.portal.model;

public enum AilmentCategory {

	ORTHOPAIDICS,
	UROLOGY
}
