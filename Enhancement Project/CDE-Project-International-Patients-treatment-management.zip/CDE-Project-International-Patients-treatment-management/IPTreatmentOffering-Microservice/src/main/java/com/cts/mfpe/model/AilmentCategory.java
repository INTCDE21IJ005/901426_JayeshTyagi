package com.cts.mfpe.model;

public enum AilmentCategory {

	ORTHOPAIDICS,
	UROLOGY
}
